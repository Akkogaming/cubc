import mysql.connector

while True:
    print("\nBienvenido a la Cafeteria ====")
    print("1. Ver Productos")
    print("2. Salir")

    opcion = input("Seleccione una opción: ")

    if opcion == "1":
        conexion =  mysql.connector.connect(
             host="localhost",
             user="root",
             password="",
             database="Cafeteria"
         )
        cursor = conexion.cursor()

        cursor.execute("SELECT * FROM Productos")

        Productos = cursor.fetchall()

        print("\n---Productos Disponibles ---")

        for Producto in Productos:
            print(Productos)

        conexion.close()

    elif opcion == "2":
        print("Gracias por visitar la Cafeteria")
        break
    
    else:
        print("Opción no válida, por favor intente de nuevo")
